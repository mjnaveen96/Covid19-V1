import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  loginStatus = true;
  loginForm = new FormGroup({
    username: new FormControl('', Validators.required),
    password: new FormControl('', Validators.required),
  });

  constructor(
    private router: Router
  ) { }

  ngOnInit(): void {
    localStorage.removeItem('loginStaus');
  }

  /*
  * @desc: Login button click func user validation
  */
  onSubmit(): void {
    try {
      const loginData = JSON.parse(localStorage.getItem('login') || '{}');
      if (this.loginForm.value.username === loginData.username &&
        this.loginForm.value.password === loginData.password) {
        localStorage.setItem('loginStatus', 'true');
        this.loginStatus = true;
        this.router.navigateByUrl('/dashboard');
      } else {
        localStorage.setItem('loginStatus', 'false');
        this.loginStatus = false;
      }
    } catch (error) {
      console.log(error);
    }
  }

}
