import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router, NavigationEnd } from '@angular/router';
import { filter, map, mergeMap } from 'rxjs/operators';
import { AuthGuard } from './auth/services/auth.guard';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {

  title = 'covid19';
  showHeader = false;

  constructor(
    private router: Router
  ) { };

  ngOnInit(): void {
    localStorage.setItem('login', JSON.stringify({ username: 'fingent', password: 'fingent' }));
    this.setIntervalFun();
  }

  /*
  * @desc: Function for checking login page
  */
  setIntervalFun() {
    try {
      setInterval(() => {
        if (this.router.url === '/login') {
          localStorage.removeItem('loginStatus');
          localStorage.removeItem('editedData');
          localStorage.removeItem('filterData');
          this.showHeader = false;
        } else {
          this.showHeader = true;
        }
      }, 500);
    } catch (error) {
      console.log(error);
    }
  }

}
