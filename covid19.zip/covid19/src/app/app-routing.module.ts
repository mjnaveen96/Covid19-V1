import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './auth/components/login/login.component';
import { AuthGuard } from './auth/services/auth.guard';
import { CountryListComponent } from './feature/components/country-list/country-list.component';
import { DashboardComponent } from './feature/components/dashboard/dashboard.component';
import { EditCountryRecordComponent } from './feature/components/edit-country-record/edit-country-record.component';
import { CountryListResolver } from './feature/services/country-list.resolver';
import { CountryEditResolver } from './feature/services/country-edit.resolver';
import { DashboardResolver } from './feature/services/dashboard.resolver';

const routes: Routes = [
  { path: 'login', component: LoginComponent },
  {
    path: 'dashboard',
    canActivate: [AuthGuard],
    resolve: {
      DashboardResolver: DashboardResolver
    },
    component: DashboardComponent
  },
  {
    path: 'countrylist',
    canActivate: [AuthGuard],
    resolve: {
      CountryResolver: CountryListResolver
    },
    component: CountryListComponent
  },
  {
    path: 'editcountry/:id',
    canActivate: [AuthGuard],
    resolve: {
      CountryEditResolver: CountryEditResolver
    },
    component: EditCountryRecordComponent
  },
  { path: '', redirectTo: 'login', pathMatch: 'full' },
  { path: '**', redirectTo: 'login' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
