import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-country-list',
  templateUrl: './country-list.component.html',
  styleUrls: ['./country-list.component.scss']
})
export class CountryListComponent implements OnInit {

  countryList: any;
  filteredCountryList: any;
  searchString = '';
  selectedValue = '';
  paginationData: any;

  constructor(
    private route: ActivatedRoute,
    private router: Router
  ) {
    try {
      this.route.data.subscribe(resp => {
        if (resp?.CountryResolver) {
          this.filteredCountryList = this.countryList = resp.CountryResolver;
        }
      });
    } catch (error) {
      console.log(error);
    }
  }

  ngOnInit(): void {
    this.setPaginationData();
    this.setDefaultData();
    this.selectedValue = '';
  }

  /*
  * @desc: Function for populating the filter data and sorted data
  */
  setDefaultData(): void {
    try {
      const editData = JSON.parse(localStorage.getItem('editedData') || '{}');
      const filterData = JSON.parse(localStorage.getItem('filterData') || '{}');
      if (editData !== null && editData.id)
        for (const item of this.filteredCountryList) {
          if (item.countryInfo._id === editData.id) {
            item.cases = editData.editObj.cases;
            item.deaths = editData.editObj.deaths;
            item.recovered = editData.editObj.recovered;
            item.tests = editData.editObj.tests;
          }
        }
      this.selectedValue = filterData.dropData;
      this.dropChange();
      this.searchString = filterData.searchString;
      this.searchCountry();
      this.pageChanged(filterData.currentPage);
      localStorage.removeItem('editedData');
      localStorage.removeItem('filterData');
    } catch (error) {
      console.log(error);
    }
  }

  /*
  * @desc: Function for searching the country
  */
  searchCountry(): void {
    try {
      console.log(this.searchString);
      if (this.searchString !== '' && this.searchString !== undefined) {
        this.filteredCountryList = this.countryList.filter((x: { country: string | undefined; }) =>
          x?.country?.toLowerCase() === this.searchString?.toLowerCase());
      } else {
        this.filteredCountryList = this.countryList;
      }
    } catch (error) {
      console.log(error);
    }
  }

  /*
  * @desc: Function for sorting the country list according to the filter
  */
  dropChange(): void {
    try {
      if (this.selectedValue !== '') {
        switch (this.selectedValue) {
          case 'name':
            this.sortByName();
            break;
          case 'case':
            this.sortByCase();
            break;
          case 'death':
            this.sortByDeath();
            break;
          case 'recover':
            this.sortByRecover();
            break;
        }
      } else {
        this.filteredCountryList = this.countryList;
      }
    } catch (error) {
      console.log(error);
    }
  }

  /*
  * @desc: Function for sorting the country list according to name in ascending order
  */
  sortByName(): void {
    try {
      this.filteredCountryList = this.countryList.sort((a: any, b: any) => (a.country > b.country) ? 1 : ((b.country > a.country) ? -1 : 0));
    } catch (error) {
      console.log(error);
    }
  }

  /*
  * @desc: Function for sorting the country list according to no of Cases in ascending order
  */
  sortByCase(): void {
    try {
      this.filteredCountryList = this.countryList.sort((a: any, b: any) => parseFloat(a.cases) - parseFloat(b.cases));
    } catch (error) {
      console.log(error);
    }
  }

  /*
  * @desc: Function for sorting the country list according to no of Deaths in ascending order
  */
  sortByDeath(): void {
    try {
      this.filteredCountryList = this.countryList.sort((a: any, b: any) => parseFloat(a.deaths) - parseFloat(b.deaths));
    } catch (error) {
      console.log(error);
    }
  }

  /*
  * @desc: Function for sorting the country list according to no of Recoveries in ascending order
  */
  sortByRecover(): void {
    try {
      this.filteredCountryList = this.countryList.sort((a: any, b: any) => parseFloat(a.recovered) - parseFloat(b.recovered));
    } catch (error) {
      console.log(error);
    }
  }

  /*
  * @desc: Function triggered when we change the pagination
  * @params: Current selected page number
  */
  pageChanged(event: any) {
    try {
      this.paginationData.currentPage = event;
    } catch (error) {
      console.log(error);
    }
  }

  /*
  * @desc: Function for setting the default pagination data
  */
  setPaginationData(): void {
    try {
      this.paginationData = {
        itemsPerPage: 10,
        currentPage: 1,
        totalItems: this.filteredCountryList.length
      }
    } catch (error) {
      console.log(error);
    }
  }

  /*
  * @desc: Function for edit navigation click against each country
  * @params: Currently selected country details
  */
  editClick(data: any) {
    try {
      localStorage.setItem('filterData',
        JSON.stringify({
          searchString: this.searchString,
          dropData: this.selectedValue,
          currentPage: this.paginationData.currentPage,
        }));
      this.router.navigate(['/editcountry', data.countryInfo._id]);
    } catch (error) {
      console.log(error);
    }
  }

}

