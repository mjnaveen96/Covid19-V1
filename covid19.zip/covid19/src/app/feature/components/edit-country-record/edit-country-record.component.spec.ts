import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EditCountryRecordComponent } from './edit-country-record.component';

describe('EditCountryRecordComponent', () => {
  let component: EditCountryRecordComponent;
  let fixture: ComponentFixture<EditCountryRecordComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EditCountryRecordComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EditCountryRecordComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
