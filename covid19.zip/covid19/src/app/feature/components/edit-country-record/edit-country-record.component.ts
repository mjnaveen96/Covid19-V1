import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-edit-country-record',
  templateUrl: './edit-country-record.component.html',
  styleUrls: ['./edit-country-record.component.scss']
})
export class EditCountryRecordComponent implements OnInit {

  countryDetails: any;
  editForm = new FormGroup({
    cases: new FormControl('', Validators.required),
    deaths: new FormControl('', Validators.required),
    recovered: new FormControl('', Validators.required),
    tests: new FormControl('', Validators.required),
  });

  constructor(
    private route: ActivatedRoute,
    private router: Router
  ) {
    try {
      this.route.data.subscribe(resp => {
        if (resp?.CountryEditResolver) {
          this.countryDetails = resp.CountryEditResolver;
        }
      });
    } catch (error) {
      console.log(error);
    }
  }

  ngOnInit(): void {
    this.setDefaultData();
  }

  /*
  * @desc: Function for initializing the input fields
  */
  setDefaultData(): void {
    try {
      // this.editForm.controls.cases.setValue(this.countryDetails.cases);
      // this.editForm.controls.deaths.setValue(this.countryDetails.deaths);
      // this.editForm.controls.recovered.setValue(this.countryDetails.recovered);
      // this.editForm.controls.tests.setValue(this.countryDetails.tests);
    } catch (error) {
      console.log(error);
    }
  }

  /*
  * @desc: Function for save the edited details and navigation to country listing page
  */
  onSubmit(): void {
    try {
      localStorage.setItem(
        'editedData',
        JSON.stringify({ editObj: this.editForm.value, id: this.countryDetails.countryInfo._id }));
      this.router.navigateByUrl('/countrylist');
    } catch (error) {
      console.log(error);
    }
  }

  /*
  * @desc: Function for cancel editing and navigation to country listing page
  */
  cancel(): void {
    try {
      this.router.navigateByUrl('/countrylist');
    } catch (error) {
      console.log(error);
    }
  }

}
