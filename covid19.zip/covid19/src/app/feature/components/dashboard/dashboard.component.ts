import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {

  covidDetails: any;

  constructor(
    private route: ActivatedRoute,
  ) {
    try {
      this.route.data.subscribe(resp => {
        if (resp?.DashboardResolver) {
          this.covidDetails = resp.DashboardResolver;
        }
      });
    } catch (error) {
      console.log(error);
    }
  }

  ngOnInit(): void {
  }

}
