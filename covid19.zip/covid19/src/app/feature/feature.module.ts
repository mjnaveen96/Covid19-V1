import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { CountryListComponent } from './components/country-list/country-list.component';
import { NgxPaginationModule } from 'ngx-pagination';
import { EditCountryRecordComponent } from './components/edit-country-record/edit-country-record.component';
import { SharedModule } from '../shared/shared.module';

@NgModule({
  declarations: [
    DashboardComponent,
    CountryListComponent,
    EditCountryRecordComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    NgxPaginationModule,
    SharedModule
  ],
  exports: [
    DashboardComponent,
    CountryListComponent,
    EditCountryRecordComponent
  ]
})
export class FeatureModule { }
