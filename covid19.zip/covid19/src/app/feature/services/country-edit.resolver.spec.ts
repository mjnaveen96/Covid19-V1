import { TestBed } from '@angular/core/testing';

import { CountryEditResolver } from './country-edit.resolver';

describe('CountryEditResolver', () => {
  let resolver: CountryEditResolver;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    resolver = TestBed.inject(CountryEditResolver);
  });

  it('should be created', () => {
    expect(resolver).toBeTruthy();
  });
});
