import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class CommonService {

  constructor() { }

  canActivate(): boolean {
    const loginStatus = JSON.parse(localStorage.getItem('loginStatus') || '');
    if (loginStatus !== (null || 'null') && loginStatus !== undefined
      && loginStatus !== '' && loginStatus === true) {
      return true;
    } else {
      return false;
    }
  }
}
