import { CharNumberDirective } from './char-number.directive';

describe('CharNumberDirective', () => {
  it('should create an instance', () => {
    const directive = new CharNumberDirective();
    expect(directive).toBeTruthy();
  });
});
