/*
* Angular (8)
* description : Character/Number only directive
* Author : Vaishakh Sagar
*/
import { Directive, HostListener, Input, ElementRef } from '@angular/core';

@Directive({
  selector: '[appCharNumber]'
})
export class CharNumberDirective {

  /*tslint:disable-next-line:no-input-rename*/
  @Input('dataType') dataTypes = '';

  private numbers: any = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];
  private alphabets: any = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'];
  private specialKeys: Array<string> = ['Left', 'Right', 'ArrowLeft', 'ArrowRight', 'Backspace', 'Tab', 'End', 'Home', 'Delete', 'Del'];
  private alphabetsSpace: any = ['\'', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', ' ', 'Spacebar'];
  private regex: RegExp = new RegExp(/^\d*\.?\d{0,2}$/g);

  constructor(private el: ElementRef) { }

  @HostListener('keydown', ['$event'])
  /*
  * @desc:  number determination
  */
  onKeyDown(event: KeyboardEvent) {
    if (this.dataTypes === 'number') {
      if (this.numbers.indexOf(event.key) !== -1) {
        return;
      }
      else if (this.specialKeys.indexOf(event.key) !== -1) {
        return;
      }
      else {
        event.preventDefault();
      }
    }
    if (this.dataTypes == null) {
      return;
    }

  }

}
