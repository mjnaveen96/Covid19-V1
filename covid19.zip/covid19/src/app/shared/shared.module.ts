import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HeaderComponent } from './components/header/header.component';
import { CharNumberDirective } from './directives/char-number/char-number.directive';


@NgModule({
  declarations: [
    HeaderComponent,
    CharNumberDirective
  ],
  imports: [
    CommonModule
  ],
  exports: [
    HeaderComponent,
    CharNumberDirective
  ]
})
export class SharedModule { }
