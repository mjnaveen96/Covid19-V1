import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {

  @Output() showHeaderEmit: EventEmitter<any> = new EventEmitter();
  showDashboard = false;
  showCountries = false;

  constructor(
    private router: Router
  ) { }

  ngOnInit(): void {
    this.showDashboard = true;
  }

  dashboard(): void{
    try {
      this.showDashboard = true;
      this.showCountries = false;
      this.router.navigateByUrl('/dashboard');
    } catch (error) {
      console.log(error);
    }
  }

  countries(): void{
    try {
      this.showDashboard = false;
      this.showCountries = true;
      this.router.navigateByUrl('/countrylist');
    } catch (error) {
      console.log(error);
    }
  }

  /*
  * @desc: Function for logout and remove the stored data in storage
  */
  logout(): void {
    try {
      localStorage.removeItem('loginStatus');
      localStorage.removeItem('editedData');
      localStorage.removeItem('filterData');
      this.showHeaderEmit.emit();
      this.router.navigateByUrl('/login');
    } catch (error) {
      console.log(error);
    }
  }
}
