export const environment = {
  apiBaseURL: 'https://corona.lmao.ninja/v2',
  production: true
};
